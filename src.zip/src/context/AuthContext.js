import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import {
  loginWithEmail,
  logout as firebaseLogout,
  registerWithEmail,
  resetPassword,
} from '../services/authService';
import { demoCredentials } from '../services/demoCredentials';
import { auth, isFirebaseConfigured } from '../services/firebase';

const AuthContext = createContext(null);

const demoUser = {
  uid: 'demo-user',
  displayName: 'Demo User',
  email: demoCredentials.email,
  isDemo: true,
};

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [initializing, setInitializing] = useState(true);

  useEffect(() => {
    if (!isFirebaseConfigured) {
      setInitializing(false);
      return undefined;
    }

    const unsubscribe = onAuthStateChanged(auth, (nextUser) => {
      setUser(nextUser);
      setInitializing(false);
    });

    return unsubscribe;
  }, []);

  const login = useCallback(async (email, password) => {
    const isDemoLogin =
      email.trim().toLowerCase() === demoCredentials.email.toLowerCase() &&
      password === demoCredentials.password;

    if (isDemoLogin) {
      setUser(demoUser);
      return { user: demoUser };
    }

    if (!isFirebaseConfigured) {
      throw new Error(
        'Firebase is not configured yet. Use the demo login or add your Firebase keys.',
      );
    }

    return loginWithEmail(email, password);
  }, []);

  const logout = useCallback(async () => {
    if (user?.isDemo || !isFirebaseConfigured) {
      setUser(null);
      return;
    }

    return firebaseLogout();
  }, [user?.isDemo]);

  const value = useMemo(
    () => ({
      user,
      initializing,
      login,
      register: registerWithEmail,
      resetPassword,
      logout,
    }),
    [initializing, login, logout, user],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);

  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider.');
  }

  return context;
}
