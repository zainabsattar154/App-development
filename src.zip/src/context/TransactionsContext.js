import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import {
  createTransaction,
  removeTransaction,
  subscribeToTransactions,
  updateTransaction,
} from '../services/transactionService';
import { useAuth } from './AuthContext';

const TransactionsContext = createContext(null);

const demoTransactionsSeed = [
  {
    id: 'demo-1',
    title: 'Monthly salary',
    amount: 4200,
    category: 'Salary',
    type: 'income',
    date: new Date(),
  },
  {
    id: 'demo-2',
    title: 'Groceries',
    amount: 86.45,
    category: 'Food',
    type: 'expense',
    date: new Date(),
  },
  {
    id: 'demo-3',
    title: 'Internet bill',
    amount: 58,
    category: 'Bills',
    type: 'expense',
    date: new Date(),
  },
  {
    id: 'demo-4',
    title: 'Freelance project',
    amount: 750,
    category: 'Freelance',
    type: 'income',
    date: new Date(),
  },
];

export function TransactionsProvider({ children }) {
  const { user } = useAuth();
  const [transactions, setTransactions] = useState([]);
  const [demoTransactions, setDemoTransactions] = useState(demoTransactionsSeed);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!user?.uid) {
      setTransactions([]);
      setLoading(false);
      return undefined;
    }

    if (user.isDemo) {
      setTransactions(demoTransactions);
      setError(null);
      setLoading(false);
      return undefined;
    }

    setLoading(true);
    const unsubscribe = subscribeToTransactions(
      user.uid,
      (nextTransactions) => {
        setTransactions(nextTransactions);
        setError(null);
        setLoading(false);
      },
      (firestoreError) => {
        setError(firestoreError);
        setLoading(false);
      },
    );

    return unsubscribe;
  }, [demoTransactions, user?.isDemo, user?.uid]);

  const summary = useMemo(() => {
    const totals = transactions.reduce(
      (acc, transaction) => {
        if (transaction.type === 'income') {
          acc.income += transaction.amount;
        } else {
          acc.expenses += transaction.amount;
        }

        return acc;
      },
      { income: 0, expenses: 0 },
    );

    const balance = totals.income - totals.expenses;

    return {
      totalIncome: totals.income,
      totalExpenses: totals.expenses,
      totalBalance: balance,
      savings: Math.max(balance, 0),
    };
  }, [transactions]);

  const actions = useMemo(
    () => {
      if (user?.isDemo) {
        return {
          addTransaction: async (transaction) => {
            setDemoTransactions((current) => [
              {
                ...transaction,
                id: `demo-${Date.now()}`,
                amount: Number(transaction.amount),
                date: new Date(transaction.date),
              },
              ...current,
            ]);
          },
          editTransaction: async (transactionId, transaction) => {
            setDemoTransactions((current) =>
              current.map((item) =>
                item.id === transactionId
                  ? {
                      ...item,
                      ...transaction,
                      amount: Number(transaction.amount),
                      date: new Date(transaction.date),
                    }
                  : item,
              ),
            );
          },
          deleteTransaction: async (transactionId) => {
            setDemoTransactions((current) =>
              current.filter((item) => item.id !== transactionId),
            );
          },
        };
      }

      return {
        addTransaction: (transaction) => createTransaction(user.uid, transaction),
        editTransaction: (transactionId, transaction) =>
          updateTransaction(user.uid, transactionId, transaction),
        deleteTransaction: (transactionId) =>
          removeTransaction(user.uid, transactionId),
      };
    },
    [user?.isDemo, user?.uid],
  );

  const value = useMemo(
    () => ({
      transactions,
      loading,
      error,
      summary,
      ...actions,
    }),
    [actions, error, loading, summary, transactions],
  );

  return (
    <TransactionsContext.Provider value={value}>
      {children}
    </TransactionsContext.Provider>
  );
}

export function useTransactions() {
  const context = useContext(TransactionsContext);

  if (!context) {
    throw new Error(
      'useTransactions must be used within a TransactionsProvider.',
    );
  }

  return context;
}
