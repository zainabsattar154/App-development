export const demoCredentials = {
  email: 'demo@spendwise.app',
  password: 'SpendWise123',
};
