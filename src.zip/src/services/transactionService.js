import {
  Timestamp,
  addDoc,
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  updateDoc,
} from 'firebase/firestore';
import { db } from './firebase';

const transactionCollection = (uid) =>
  collection(db, 'users', uid, 'transactions');

const normalizeDate = (value) => {
  if (value instanceof Date) {
    return value;
  }

  if (value?.toDate) {
    return value.toDate();
  }

  return new Date(value);
};

const mapTransaction = (documentSnapshot) => {
  const data = documentSnapshot.data();

  return {
    id: documentSnapshot.id,
    ...data,
    amount: Number(data.amount || 0),
    date: normalizeDate(data.date),
    createdAt: data.createdAt?.toDate?.() || null,
    updatedAt: data.updatedAt?.toDate?.() || null,
  };
};

const payloadFromTransaction = (transaction) => ({
  title: transaction.title.trim(),
  amount: Number(transaction.amount),
  category: transaction.category,
  type: transaction.type,
  date: Timestamp.fromDate(normalizeDate(transaction.date)),
  notes: transaction.notes?.trim?.() || '',
  updatedAt: serverTimestamp(),
});

export function subscribeToTransactions(uid, onData, onError) {
  if (!uid) {
    return () => {};
  }

  const transactionsQuery = query(
    transactionCollection(uid),
    orderBy('date', 'desc'),
  );

  return onSnapshot(
    transactionsQuery,
    (snapshot) => onData(snapshot.docs.map(mapTransaction)),
    onError,
  );
}

export async function createTransaction(uid, transaction) {
  return addDoc(transactionCollection(uid), {
    ...payloadFromTransaction(transaction),
    createdAt: serverTimestamp(),
  });
}

export async function updateTransaction(uid, transactionId, transaction) {
  const transactionDoc = doc(db, 'users', uid, 'transactions', transactionId);
  return updateDoc(transactionDoc, payloadFromTransaction(transaction));
}

export async function removeTransaction(uid, transactionId) {
  const transactionDoc = doc(db, 'users', uid, 'transactions', transactionId);
  return deleteDoc(transactionDoc);
}
